module com.example.dbfinalproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql; // Database connector ke liye zaroori hai


    opens com.example.dbfinalproject to javafx.fxml;
    exports com.example.dbfinalproject;

    // In do lines ko lazmi add karo taake JavaFX aapke banaye packages ko pehchan sakay
    exports view;
    opens view to javafx.fxml;
}