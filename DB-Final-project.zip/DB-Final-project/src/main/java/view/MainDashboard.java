package view;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import util.DBConnection;
import util.InputValidator;

import java.sql.*;
import java.time.LocalDate;

public class MainDashboard extends Application {

    private TableView<Member> table = new TableView<>();
    private ObservableList<Member> memberList = FXCollections.observableArrayList();

    private TextField txtName = new TextField();
    private TextField txtEmail = new TextField();
    private TextField txtPhone = new TextField();
    private DatePicker dpDob = new DatePicker();
    private ComboBox<String> cmbGender = new ComboBox<>();
    private Button btnSave = new Button("➕ Add New Member");
    private Button btnClear = new Button("🧹 Clear Form");

    private boolean isEditMode = false;
    private int selectedMemberId = -1;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("IRON PULSE | Gym Management System");

        // ----------------------------------------------------
        // 1. TOP MENU BAR (Dark Mode Styled)
        // ----------------------------------------------------
        MenuBar menuBar = new MenuBar();
        menuBar.setStyle("-fx-background-color: #2f3542; -fx-text-fill: white;");
        Menu fileMenu = new Menu("System");
        fileMenu.setStyle("-fx-text-fill: white;");
        MenuItem exitItem = new MenuItem("Exit Application");
        exitItem.setOnAction(e -> primaryStage.close());
        fileMenu.getItems().add(exitItem);
        menuBar.getMenus().add(fileMenu);

        // ----------------------------------------------------
        // 2. SIDEBAR NAVIGATION PANEL (Aggressive Gym Vibe)
        // ----------------------------------------------------
        VBox sidebar = new VBox(20);
        sidebar.setPadding(new Insets(25, 15, 15, 15));
        sidebar.setPrefWidth(220);
        sidebar.setStyle("-fx-background-color: #1e222b; -fx-border-color: #2f3542; -fx-border-width: 0 2 0 0;");
        sidebar.setAlignment(Pos.TOP_CENTER);

        Label lblLogo = new Label("🏋️ IRON PULSE");
        lblLogo.setStyle("-fx-text-fill: #00d2d3; -fx-font-weight: bold; -fx-font-size: 22px; -fx-font-family: 'Segoe UI', Arial;");

        Label lblSubLogo = new Label("FITNESS CLUB");
        lblSubLogo.setStyle("-fx-text-fill: #747d8c; -fx-font-size: 11px; -fx-font-weight: bold; -fx-letter-spacing: 2px;");

        // Simple Aesthetic Stats Indicators for Sidebar
        VBox statsBox = new VBox(10);
        statsBox.setPadding(new Insets(20, 10, 10, 10));
        statsBox.setStyle("-fx-background-color: #2f3542; -fx-background-radius: 8px;");
        Label lblStatusTitle = new Label("SYSTEM STATUS");
        lblStatusTitle.setStyle("-fx-text-fill: #a4b0be; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label lblDbStatus = new Label("● Live Sync Active");
        lblDbStatus.setStyle("-fx-text-fill: #2ed573; -fx-font-size: 13px; -fx-font-weight: bold;");
        statsBox.getChildren().addAll(lblStatusTitle, lblDbStatus);

        sidebar.getChildren().addAll(lblLogo, lblSubLogo, new Separator(), statsBox);

        // ----------------------------------------------------
        // 3. INPUT FORM PANEL (GridPane inside Styled Card)
        // ----------------------------------------------------
        GridPane formPane = new GridPane();
        formPane.setPadding(new Insets(20));
        formPane.setHgap(15);
        formPane.setVgap(15);
        formPane.setStyle("-fx-background-color: #2f3542; -fx-background-radius: 10px; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 4);");

        // Fields Styling Wrapper Utility Method call simulation via inline styles
        String fieldStyle = "-fx-background-color: #3f4554; -fx-text-fill: white; -fx-background-radius: 5px; -fx-padding: 8px; -fx-border-color: #57606f; -fx-border-radius: 5px;";
        txtName.setStyle(fieldStyle); txtName.setPromptText("Enter full name...");
        txtEmail.setStyle(fieldStyle); txtEmail.setPromptText("example@gym.com");
        txtPhone.setStyle(fieldStyle); txtPhone.setPromptText("e.g., 03001234567");
        dpDob.setStyle(fieldStyle);
        cmbGender.setStyle("-fx-background-color: #3f4554; -fx-text-fill: white; -fx-background-radius: 5px;");
        cmbGender.setPromptText("Select Gender");
        cmbGender.getItems().addAll("Male", "Female", "Other");

        // Labels Styling
        String labelStyle = "-fx-text-fill: #f1f2f6; -fx-font-weight: bold; -fx-font-size: 13px;";
        Label lblN = new Label("Full Name:"); lblN.setStyle(labelStyle);
        Label lblE = new Label("Email Address:"); lblE.setStyle(labelStyle);
        Label lblP = new Label("Phone Matrix:"); lblP.setStyle(labelStyle);
        Label lblD = new Label("Date of Birth:"); lblD.setStyle(labelStyle);
        Label lblG = new Label("Gender Group:"); lblG.setStyle(labelStyle);

        formPane.add(lblN, 0, 0); formPane.add(txtName, 1, 0);
        formPane.add(lblE, 0, 1); formPane.add(txtEmail, 1, 1);
        formPane.add(lblP, 0, 2); formPane.add(txtPhone, 1, 2);
        formPane.add(lblD, 0, 3); formPane.add(dpDob, 1, 3);
        formPane.add(lblG, 0, 4); formPane.add(cmbGender, 1, 4);

        // Buttons Custom Styling (Neon Vibe)
        btnSave.setStyle("-fx-background-color: #00d2d3; -fx-text-fill: #1e222b; -fx-font-weight: bold; -fx-font-size: 13px; -fx-padding: 10px 20px; -fx-cursor: hand;");
        btnClear.setStyle("-fx-background-color: #747d8c; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 13px; -fx-padding: 10px 20px; -fx-cursor: hand;");

        HBox formButtons = new HBox(12, btnSave, btnClear);
        formButtons.setPadding(new Insets(10, 0, 0, 0));
        formPane.add(formButtons, 1, 5);

        // ----------------------------------------------------
        // 4. DATA TABLE SETUP (Cyber Dark Theme Grid)
        // ----------------------------------------------------
        table.setStyle("-fx-background-color: #2f3542; -fx-border-color: #57606f;");

        TableColumn<Member, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colId.setPrefWidth(50);

        TableColumn<Member, String> colName = new TableColumn<>("Full Name");
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colName.setPrefWidth(180);

        TableColumn<Member, String> colEmail = new TableColumn<>("Email Registry");
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colEmail.setPrefWidth(200);

        TableColumn<Member, String> colPhone = new TableColumn<>("Contact No");
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        colPhone.setPrefWidth(130);

        TableColumn<Member, String> colStatus = new TableColumn<>("Status");
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        colStatus.setPrefWidth(90);

        // Table Action Buttons Cell Styling
        TableColumn<Member, Void> colActions = new TableColumn<>("Manage Record");
        colActions.setPrefWidth(160);
        colActions.setCellFactory(param -> new TableCell<>() {
            private final Button editBtn = new Button("📝 Edit");
            private final Button deleteBtn = new Button("🗑️");
            private final HBox rowActionContainer = new HBox(8, editBtn, deleteBtn);

            {
                editBtn.setStyle("-fx-background-color: #ff9f43; -fx-text-fill: black; -fx-font-weight: bold; -fx-font-size: 11px; -fx-cursor: hand;");
                deleteBtn.setStyle("-fx-background-color: #ee5253; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 11px; -fx-cursor: hand;");
                rowActionContainer.setAlignment(Pos.CENTER);

                editBtn.setOnAction(event -> {
                    Member m = getTableView().getItems().get(getIndex());
                    populateFormForEdit(m);
                });
                deleteBtn.setOnAction(event -> {
                    Member m = getTableView().getItems().get(getIndex());
                    deleteMemberFromDB(m.getId());
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(rowActionContainer);
                }
            }
        });

        table.getColumns().addAll(colId, colName, colEmail, colPhone, colStatus, colActions);

        // ----------------------------------------------------
        // 5. MASTER CONTAINER INTEGRATION
        // ----------------------------------------------------
        BorderPane mainLayout = new BorderPane();
        mainLayout.setStyle("-fx-background-color: #1e222b;"); // Main Screen Midnight Dark Dark
        mainLayout.setTop(menuBar);
        mainLayout.setLeft(sidebar);

        // Center Content Body VBox
        VBox centerArea = new VBox(15);
        centerArea.setPadding(new Insets(20));

        Label lblFormHeader = new Label("🛡️ ATHLETE REGISTRATION & UPDATE PROFILE");
        lblFormHeader.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 15px; -fx-letter-spacing: 0.5px;");

        Label lblTableHeader = new Label("📋 ACTIVE MEMBERS DATABASE CORE");
        lblTableHeader.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 15px; -fx-letter-spacing: 0.5px;");

        centerArea.getChildren().addAll(lblFormHeader, formPane, lblTableHeader, table);
        mainLayout.setCenter(centerArea);

        // Core Event Handlers
        btnSave.setOnAction(e -> handleSaveAction());
        btnClear.setOnAction(e -> clearForm());

        // Initial Data Sync Call
        loadMembersFromDatabase();

        Scene scene = new Scene(mainLayout, 1150, 720);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void loadMembersFromDatabase() {
        memberList.clear();
        String query = "SELECT member_id, full_name, email, phone, status FROM Members";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                memberList.add(new Member(
                        rs.getInt("member_id"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("status")
                ));
            }
            table.setItems(memberList);
        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Database Access Error", ex.getMessage());
        }
    }

    private void handleSaveAction() {
        String name = txtName.getText();
        String email = txtEmail.getText();
        String phone = txtPhone.getText();
        LocalDate dob = dpDob.getValue();
        String gender = cmbGender.getValue();

        if (InputValidator.isEmpty(name) || InputValidator.isEmpty(email) || !InputValidator.isValidEmail(email)) {
            showAlert(Alert.AlertType.WARNING, "Metrics Guard", "Valid Name and Active Email required!");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            if (isEditMode) {
                String updateQuery = "UPDATE Members SET full_name=?, email=?, phone=? WHERE member_id=?";
                try (PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
                    pstmt.setString(1, name);
                    pstmt.setString(2, email);
                    pstmt.setString(3, phone);
                    pstmt.setInt(4, selectedMemberId);
                    pstmt.executeUpdate();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Member stats locked and updated.");
                }
            } else {
                String insertQuery = "INSERT INTO Members (full_name, email, phone, dob, gender, status) VALUES (?, ?, ?, ?, ?, 'Active')";
                try (PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
                    pstmt.setString(1, name);
                    pstmt.setString(2, email);
                    pstmt.setString(3, phone);
                    pstmt.setDate(4, dob != null ? Date.valueOf(dob) : null);
                    pstmt.setString(5, gender);
                    pstmt.executeUpdate();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "New Gym Member deployed successfully.");
                }
            }
            clearForm();
            loadMembersFromDatabase();
        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Transaction Failed", ex.getMessage());
        }
    }

    private void populateFormForEdit(Member m) {
        isEditMode = true;
        selectedMemberId = m.getId();
        txtName.setText(m.getName());
        txtEmail.setText(m.getEmail());
        txtPhone.setText(m.getPhone());
        btnSave.setText("🔄 Update Athlete");
        btnSave.setStyle("-fx-background-color: #ff9f43; -fx-text-fill: black; -fx-font-weight: bold; -fx-padding: 10px 20px;");
    }

    private void deleteMemberFromDB(int id) {
        String deleteQuery = "DELETE FROM Members WHERE member_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(deleteQuery)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            showAlert(Alert.AlertType.INFORMATION, "Purged", "Member erased from live index.");
            loadMembersFromDatabase();
        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Execution Error", ex.getMessage());
        }
    }

    private void clearForm() {
        txtName.clear();
        txtEmail.clear();
        txtPhone.clear();
        dpDob.setValue(null);
        cmbGender.setValue(null);
        btnSave.setText("➕ Add New Member");
        btnSave.setStyle("-fx-background-color: #00d2d3; -fx-text-fill: #1e222b; -fx-font-weight: bold; -fx-padding: 10px 20px;");
        isEditMode = false;
        selectedMemberId = -1;
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static class Member {
        private final int id;
        private final String name;
        private final String email;
        private final String phone;
        private final String status;

        public Member(int id, String name, String email, String phone, String status) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.phone = phone;
            this.status = status;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getPhone() { return phone; }
        public String getStatus() { return status; }
    }
}